export default function GuidesPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">가이드 정보</h1>
      <p className="text-muted-foreground">현지 가이드 정보, 여행 팁, Q&A를 공유합니다. (콘텐츠 준비 중)</p>
      {/* TODO: Add guide specific content and layout */}
    </div>
  );
}
