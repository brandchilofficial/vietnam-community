export default function JobsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">구인구직</h1>
      <p className="text-muted-foreground">구인구직 관련 게시판입니다. (콘텐츠 준비 중)</p>
      {/* TODO: Add job specific content and layout */}
    </div>
  );
}
