export default function VnCommunityPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">베트남 커뮤니티</h1>
      <p className="text-muted-foreground">베트남 현지인들을 위한 자유로운 소통 공간입니다. (콘텐츠 준비 중)</p>
      {/* TODO: Add Vietnamese community specific content and layout */}
    </div>
  );
}
