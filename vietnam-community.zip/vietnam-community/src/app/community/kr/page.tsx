export default function KrCommunityPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">한국인 커뮤니티</h1>
      <p className="text-muted-foreground">베트남 거주 한국인들의 정보 교류 및 생활 공유 게시판입니다. (콘텐츠 준비 중)</p>
      {/* TODO: Add Korean community specific content and layout */}
    </div>
  );
}
