export default function NewsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">현지뉴스</h1>
      <p className="text-muted-foreground">현지 뉴스 게시판입니다. (콘텐츠 준비 중)</p>
      {/* TODO: Add news specific content and layout */}
    </div>
  );
}
