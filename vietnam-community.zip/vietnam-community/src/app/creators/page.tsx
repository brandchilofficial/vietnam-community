export default function CreatorsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">크리에이터</h1>
      <p className="text-muted-foreground">베트남 관련 틱톡, 유튜브 크리에이터들을 만나보세요. (콘텐츠 준비 중)</p>
      {/* TODO: Add creator specific content and layout */}
    </div>
  );
}
