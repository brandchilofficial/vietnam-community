export default function PromotionsPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">업체 홍보</h1>
      <p className="text-muted-foreground">사장님들의 가게 및 서비스 홍보 공간입니다. (콘텐츠 준비 중)</p>
      {/* TODO: Add promotion specific content and layout */}
    </div>
  );
}
