export default function BizPage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">현지업체</h1>
      <p className="text-muted-foreground">현지 업체 정보 게시판입니다. (콘텐츠 준비 중)</p>
      {/* TODO: Add business specific content and layout */}
    </div>
  );
}
